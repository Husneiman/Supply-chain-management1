package com.nit.ali.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nit.ali.model.ShipmentType;
import com.nit.ali.service.IShimentTypeService;

@Controller
@RequestMapping("/st")
public class ShipmentTypeController {
	@Autowired
	private IShimentTypeService service;
	//1. Show Register page
	@GetMapping("/register")
	public String showReg() {
		return "ShipmentTypeRegister";
	}

	//2. Onclick submit button and save the data
	@PostMapping("/save")
	public String saveShipmentType(
			@ModelAttribute ShipmentType shipmentType, Model model) {
		// CAll service method
		Integer id=service.saveShipmentType( shipmentType);
		// create message
		String message="ShipmentTypeRegister:" + id+":saved";
		// sent message to UI
		model.addAttribute("message", message);
		return "ShipmentTypeRegister";
	}
	//3. Display all rows
	@GetMapping("/all")
	public String showAllShipmentTypes(
			Model model )
	{
		// call service layer
		List<ShipmentType> list =
				service.getAllShipmentTypes();
		//send data to UI
		model.addAttribute("list", list);
		//Go back to UI page
		return "ShipmentTypeData";
	}
	//4.  Delete Id and read this is by using Request param
	@GetMapping("/delete")

	public String deleteShipmentType(@RequestParam("id")Integer
			sid,
			//read param
			Model model) {
		// check id si exits or not
		if(service.isShimentTypeExist(sid)) {
			// call service layer
			service.deleteShipmentType(sid);
			// construct a message
			//String message=" delete shipmentType"+sid+ "Deleted";
			// construct  a message by using StringBuffer
			String message=new StringBuffer().append("shipmentType")
					.append(sid).append("Deleted")
					.toString();
			System.out.println("true");
			// Send to UI
			model.addAttribute("message", message);
		} else {
			model.addAttribute("message", sid+ "not found");
		}
		// get Latest Data
		model.addAttribute("list",service.getAllShipmentTypes());

		return "ShipmentTypeData";
	}
	// Edit  process
	@GetMapping("/edit")
	public String showShipmentTypeEdit(
			@RequestParam("id")Integer sid,
			Model model
			)
	{
		String page = null;
		Optional<ShipmentType> opt =
				service.getOneShipmentType(sid);
		if(opt.isPresent()) { //if data is present (not null)
			//object --> Fill in Form
			model.addAttribute("shipmentType", opt.get());
			page = "ShipmentTypeEdit";
		} else {
			// response.sendRedirect("/all");
			page = "redirect:all";
		}
		return page;
	}
	// Update Process
	@PostMapping("/update")
	public String doUpdateShipmentType(
			@ModelAttribute ShipmentType shipmentType,
			Model model)
	{
		//call service to update
		service.updateShipmentType(shipmentType);
		//return "redirect:all";
		//send message to UI
		model.addAttribute("message", "Shipment Type'"+shipmentType.getId()+"' Updated!!");
		// call service layer for latest data
		List<ShipmentType> list =
				service.getAllShipmentTypes();
		//send data to UI for HTML table
		model.addAttribute("list", list);
		//Go back to UI page
		return "ShipmentTypeData";
	}
}
