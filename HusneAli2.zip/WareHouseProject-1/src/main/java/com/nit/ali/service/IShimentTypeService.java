package com.nit.ali.service;

import java.util.List;
import java.util.Optional;

import com.nit.ali.model.ShipmentType;

public interface IShimentTypeService {
	
					Integer saveShipmentType(ShipmentType st);
	
					List<ShipmentType> getAllShipmentTypes();
					public void deleteShipmentType(Integer id);
					 boolean isShimentTypeExist(Integer id);
					Optional<ShipmentType> getOneShipmentType(Integer id);
					void updateShipmentType(ShipmentType st);
	}
