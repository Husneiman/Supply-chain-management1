package com.nit.ali.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.ali.model.OrderMethod;
import com.nit.ali.repository.OrderMethodRepository;
import com.nit.ali.service.IOrderMethodService;

@Service
public class OrderMethodServiceImpl
implements IOrderMethodService
{
	@Autowired
	private OrderMethodRepository repo; //HAS-A
	@Override
	public Integer saveOrderMethod(OrderMethod om) {
		om = repo.save(om);
		Integer id = om.getId();
		return id;
	}
	@Override
	public List<OrderMethod> getAllOrderMethods() {
		List<OrderMethod> list = repo.findAll();
		return list;
	}
	@Override
	public void deleteOrderMethod(Integer id) {
		repo.deleteById(id);
	}
	@Override
	public boolean isOrderMethodExist(Integer id) {
		return repo.existsById(id);
	}
	@Override
	public Optional<OrderMethod> getOneOrderMethod(Integer id) {
		Optional<OrderMethod> opt = repo.findById(id);
		return opt;
	}
	@Override
	public void updateOrderMethod(OrderMethod om) {
		repo.save(om); //UPDATE SQL..
	}
}